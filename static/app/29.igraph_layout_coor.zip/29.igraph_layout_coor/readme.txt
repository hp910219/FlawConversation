使用说明：
Rscript get_coor_igraph.R input_nodes input_edges method outf
input_nodes:输入nodes文件
input_edges:输入edges文件
method:选择的layout 方法
outf:输出坐标文件


示例：Rscript get_coor_igraph.R test_nodes.txt test_edges.txt fr out_fr.tsv

