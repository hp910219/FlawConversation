#docker run -it -v /public/jingdu/zss:/data -v /public/jingdu/budechao/scripts/:/program bio_r
#eg:Rscript run3_herbHeatmap.R T6.kideny.coocur.class.tsv T6.png
library(corrplot)
library(RColorBrewer)
herbHeatmap<-function(inf,outf){
  data<-read.table(inf,header=T,sep="\t",quote="",stringsAsFactors=F,check.names=F)
  m<-matrix(nrow=length(unique(data[,1])),ncol=length(unique(data[,1])))
  colnames(m)=unique(data[,1])
  rownames(m)=unique(data[,1])
  for (i in 1:nrow(data)) {
    m[which(rownames(m)==data[i,2]),which(colnames(m)==data[i,1])]<-data[i,11]
    m[which(rownames(m)==data[i,1]),which(colnames(m)==data[i,2])]<-data[i,11]
  }
  m[is.na(m)]<-0
  m1<-m
  m1[m1==4|m1==-4]<-0.01
  m1[m1==3 |m1==-3]<-0.03
  m1[m1==2 |m1==-2]<-0.05
  m1[m1==1 |m1==-1]<-0.1
  m1[m1==0]<-1
  png(outf,family="GB1",width=480*2,height=480*2,res=72*2.3)	
  tags<-unique(data[,11])
  if((4 %in% tags) | (-4 %in% tags)){
    corrplot(m, method = "circle",type="upper",diag=TRUE,is.corr=FALSE,tl.cex=0.4,cl.pos="r",p.mat=m1,insig="label_sig",sig.level=0.02,pch.cex=.4,pch.col="white",col = brewer.pal(n = 8, name = "RdBu"),tl.col="#808080",cl.cex = 0.6,cl.offset=0.3)
  }else{
    corrplot(m, method = "circle",type="upper",diag=TRUE,is.corr=FALSE,tl.cex=0.4,cl.pos="r",pch.cex=.4,pch.col="white",col = brewer.pal(n = 8, name = "RdBu"),tl.col="#808080",cl.cex = 0.6,cl.offset=0.3)
  }
  dev.off()
}

args <- commandArgs(TRUE)
inf<-args[1]
outf<-args[2]
herbHeatmap(inf,outf)
