#eg:Rscript run1_format2maf.R T5.kideny.txt kideny.maf
##inf:input file with two cols(ID,Herb)
Format2Maf<-function(inf,outf){
  data<-read.table(inf,sep="\t",quote="",header=TRUE,check.names=FALSE,stringsAsFactors=FALSE)
  data$Entrez_Gene_Id<-1
  data$Center<-"genome.wustl.edu"
  data$NCBI_Build<-37
  data$Chromosome<-1
  data$Start_Position<-1:nrow(data)
  data$End_Position<-1:nrow(data)
  data$Strand<-"+"
  data$Variant_Classification<-"Splice_Site"
  data$Variant_Type<-"SNP"
  data$Reference_Allele<-"T"
  data$Tumor_Seq_Allele1<-"T"
  data$Tumor_Seq_Allele2<-"C"
  data$Tumor_Sample_Barcode<-data[,1]
  data$Protein_Change<-"p.K960R"
  data$i_TumorVAF_WU<-45.66
  data$i_transcript_name<-"NM_080282.3"
  maf<-data[,2:ncol(data)]
  colnames(maf)[1]<-"Hugo_Symbol"
  write.table(maf,outf,sep="\t",quote=F,col.names=T,row.names=F)
}

args <- commandArgs(TRUE)
inf<-args[1]
outf<-args[2]
Format2Maf(inf,outf)
