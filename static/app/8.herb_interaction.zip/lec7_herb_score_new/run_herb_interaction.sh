##ssh calc12
##docker run -it -v /public/jingdu/:/data -v /public/jingdu/zss/Rscript-zss/app/herb/:/program bio_r
##$1=work_dir,$2=db_dir,$3=input file(2 cols [ID Herb]),$4=outfile_final 
#eg:sh /program/run_herb_interaction.sh /program/ /program /program/T5.kideny.txt T6.kideny.coocur.class.tsv 20

cd $1
export PATH=$PATH:$2
Rscript $2/run1_format2maf.R $3 $3.maf
Rscript $2/run2_Interactions.R $3.maf  $4 $5
