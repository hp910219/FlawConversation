#Rscript run2_Interactions.R kideny.maf T6.kideny.coocur.class.tsv
##in_maf<-input maf file
##out_result:output file
library(maftools)
MaftoolsInteractions<-function(in_maf,out_result,top_value){
  maf<-read.maf(in_maf)
  output<-somaticInteractions(maf=maf,pvalue=c(0.05, 0.1),fontSize = 0.6,top=top_value,sigSymbolsSize = 1,nShiftSymbols=2)
  data<-as.data.frame(cbind(output$gene1,output$gene2,output$pair,output$Event,output$pValue,output$event_ratio))
  colnames(data)<-c("drug1","drug2","drug_pair","event","pValue","event_ratio")
  data1<-unlist(strsplit(data$event_ratio,"/"))
  data2<-matrix(as.numeric(data1),ncol=2,byrow=T)
  data3<-cbind(data,as.data.frame(data2))
  data4<-cbind(data3,as.data.frame(apply(data3[,7:8],1,sum)))
  colnames(data4)[c(7,8,9)]<-c("co_event","ex_event","total_event")
  data4$co_ratio<-data4$co_event/data4$total_event
  data4[as.numeric(data4[,10])<=0.001,11]<- -4
  data4[(as.numeric(data4[,10])>0.001 & as.numeric(data4[,10])<=0.002),11]<- -3
  data4[(as.numeric(data4[,10])>0.002 & as.numeric(data4[,10])<=0.005),11]<- -2
  data4[(as.numeric(data4[,10])>0.005 & as.numeric(data4[,10])<=0.01),11]<- -1
  data4[(as.numeric(data4[,10])>=0.1 & as.numeric(data4[,10])<0.15),11]<- 1
  data4[(as.numeric(data4[,10])>=0.15 & as.numeric(data4[,10]) <0.2),11]<- 2
  data4[(as.numeric(data4[,10])>=0.2 & as.numeric(data4[,10])<0.25),11]<- 3
  data4[as.numeric(data4[,10])>=0.25,11]<- 4
  data4[((as.numeric(data4[,10])>0.01 & as.numeric(data4[,10])<0.1) | as.numeric(data4[,5])>0.01),11]<- 0
  colnames(data4)[11]<-"class"
  data5<-data4[,c(1:2,10,3:9,11)]
  colnames(data5)<-c("Herb1","Herb2","Co_ratio","Herb_pair","Event","pValue","Event_ratio","Co_event","Ex_event","Total_event","Class")
  write.table(data5,out_result,sep="\t",quote=F,col.names=TRUE,row.names=FALSE)
}
args <- commandArgs(TRUE)
in_maf<-args[1]
out_result<-args[2]
top_value<-as.numeric(args[3])
MaftoolsInteractions(in_maf,out_result,top_value)
