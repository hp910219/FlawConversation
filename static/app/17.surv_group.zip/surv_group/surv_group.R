##eg:Rscript surv_group.R T1.merge.txt surv_group_result.pdf  class
library(ggplot2)
library(survival)
library(survminer)
library(ggpubr)

surv_group<-function(inf,outf,variable){
  matri<-read.table(inf,header=T,sep="\t",quote="",check.names=F,stringsAsFactors=F)
  matri$OS[which(matri$OS=="-")]<-0
  matri$OS.time[which(matri$OS.time=="-")]<-0
  matri$OS<-as.numeric(matri$OS)
  matri$OS.time<-as.numeric(matri$OS.time)
 # mySurv<-as.formula(paste('Surv(OS.time,OS)~',variable))
 # objCoxph <- coxph(formula = mySurv,data=matri)
  res.cox<-survfit(as.formula(paste('Surv(OS.time,OS)~',variable)),data=matri)
  gg=ggsurvplot(res.cox,conf.int = F,pval = T,data=matri)
  ggsave(outf,plot=print(gg),width = 18, height = 8.5, units="in")
}
args<-commandArgs(TRUE)
inf<-args[1]
outf<-args[2]
variable<-args[3]

surv_group(inf,outf,variable)
