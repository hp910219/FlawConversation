##Rscript ternaryPlot.R testf.txt test.png
##testf.txt:input file
##test.png:output file

# This part could run using external parameters 
#args <- commandArgs(TRUE)
#inf<-args[1]
#outf<-args[2]

inf="testf.txt"
outf="test.png"

library(vcd)
ternaryPlot<-function(inf,outf){
  dat <- read.table(inf,header = T,sep = "\t",quote = "",stringsAsFactors = F,check.names = F)
  dat1 <- dat
  dat1$group<-paste(dat1$label,dat1$color,sep="_")
  class=unique(dat1$group)
  if(length(unique(dat1$label))!=length(class)){
    print("ERROR:One label has more than one color!")
  }else{
  dat2=data.frame(lab1=class)
  data1<-unlist(strsplit(dat2$lab1,"_"))
  data2<-as.data.frame(matrix(data1,ncol=2,byrow=T))
  labels=data2[,1]
  color=data2[,2]
  png(outf, width = 2000, height = 2000, res = 300, units = 'px')
  ternaryplot(dat1[2:4], scale = NULL, col = dat1$color, prop_size = TRUE, cex = 2,main = 'ternaryplot')
  grid_legend(x = 0.8, y = 0.7, pch = 20, col = color, label = labels, title = "label", frame = FALSE)
  dev.off()
}
}
ternaryPlot(inf,outf)

