#signature 96 frequency
#eg:Rscript get_freq_trinucleotide.R sig_test.tsv freq96.tsv BSgenome.Hsapiens.UCSC.hg19
#sig_test.tsv:input file
#freq96.tsv：the output frequency file'
#BSgenome.Hsapiens.UCSC.hg19:referrence genome(BSgenome.Hsapiens.UCSC.hg19  or  BSgenome.Hsapiens.UCSC.hg38)

# This part could run using external parameters 
#args <- commandArgs(TRUE)
#inf<-args[1]
#outf<-args[2]
#BSg<-args[3]
inf="sig_test"
outf="freq96.tsv"
Bsg="BSgenome.Hsapiens.UCSC.hg19"

library(deconstructSigs)
library(BSgenome.Hsapiens.UCSC.hg19)
library(BSgenome.Hsapiens.UCSC.hg38)
get_freq_trinucleotide<-function(inf,outf,BSg){
  data <- read.table(inf,sep="\t",quote="",header=TRUE,stringsAsFactors = FALSE,check.names = FALSE)
  data$pos<-as.numeric(data$pos)
  data$sample<-as.character(data$sample)
  data$chr<-as.character(data$chr)
 # print(BSg)
  if(BSg=="BSgenome.Hsapiens.UCSC.hg19"){
              sigs<-mut.to.sigs.input(mut.ref=data, 
                                sample.id="sample",
                                chr="chr",
                                pos="pos",
                                ref="ref",
                                alt="alt",
                                bsg=BSgenome.Hsapiens.UCSC.hg19)}
  if(BSg=="BSgenome.Hsapiens.UCSC.hg38"){
              sigs<-mut.to.sigs.input(mut.ref=data,
                                sample.id="sample",
                                chr="chr",
                                pos="pos",
                                ref="ref",
                                alt="alt",
                                bsg=BSgenome.Hsapiens.UCSC.hg38)}
  for (i in 1:nrow(sigs)) {
    sigs[i,]<-sigs[i,]/sum(sigs[i,])
  }
  freq<-round(sigs,4)
  write.table(freq,outf,col.names = TRUE,row.names = TRUE,sep="\t",quote = F)
}
get_freq_trinucleotide(inf,outf,BSg)