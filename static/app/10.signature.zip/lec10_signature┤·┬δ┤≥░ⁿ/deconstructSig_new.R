##Rscript deconstructSig_new.R sig_test.tsv PGM25,PGM45,PGM53,PGM65,PGM7 /data/zss/Rscript-zss/app/signature/result BSgenome.Hsapiens.UCSC.hg19
#sig_test:input file
#PGM25,PGM45,PGM53,PGM65,PGM7:sample_ids
#/data/zss/Rscript-zss/app/signature/result:outdir
#BSgenome.Hsapiens.UCSC.hg19:referrence genome(BSgenome.Hsapiens.UCSC.hg19  or  BSgenome.Hsapiens.UCSC.hg38)


# This part could run using external parameters 
#args <- commandArgs(TRUE)
#sample_mut_path=args[1]
#sample_ids=args[2]
#outdir=args[3]
#BSg_type=args[4]

sample_mut_path="sig_test.tsv"
sample_ids="PGM25,PGM45,PGM53,PGM65,PGM7"
outdir="/data/zss/Rscript-zss/app/signature/result"
BSg_type="BSgenome.Hsapiens.UCSC.hg19"

library(deconstructSigs)
library(BSgenome.Hsapiens.UCSC.hg19)
library(BSgenome.Hsapiens.UCSC.hg38)

sample.mut.ref <- read.table(sample_mut_path, header=TRUE, sep="\t")
sample.mut.ref$chr<-as.character(sample.mut.ref$chr)
sample.mut.ref$sample<-as.character(sample.mut.ref$sample)
sample.mut.ref$pos<-as.numeric(sample.mut.ref$pos)
setwd(outdir)
if(BSg_type=="BSgenome.Hsapiens.UCSC.hg19"){
              sigs.input<-mut.to.sigs.input(mut.ref=sample.mut.ref, 
                                sample.id="sample",
                                chr="chr",
                                pos="pos",
                                ref="ref",
                                alt="alt",
                                bsg=BSgenome.Hsapiens.UCSC.hg19)}
  if(BSg_type=="BSgenome.Hsapiens.UCSC.hg38"){
              sigs.input<-mut.to.sigs.input(mut.ref=sample.mut.ref,
                                sample.id="sample",
                                chr="chr",
                                pos="pos",
                                ref="ref",
                                alt="alt",
                                bsg=BSgenome.Hsapiens.UCSC.hg38)}


# 遍历
sample_id_list = unlist(strsplit(sample_ids, ","))
weights_list<-list()
for(i in 1:length(sample_id_list))
{
sample_id<-sample_id_list[[i]]
one_sample = whichSignatures(tumor.ref = sigs.input, 
                           signatures.ref = signatures.cosmic,
                         #  signatures.ref = signatures.nature2013, 
                           sample.id = sample_id, 
                           contexts.needed = TRUE,
                           tri.counts.method = 'default')
write.table(one_sample$weights, file.path(outdir, paste(sample_id, ".tsv", sep="")), quote = F, row.names = F, col.names = T, sep="\t")
plotSignatures(one_sample, sub = "result")
weights_list[[i]]<-one_sample$weights
i#weights_list<-append(weights_list, one_sample$weights)
makePie(one_sample, sub = "result")
}
#names(weights_list)<-sample_id_list
weight_data<-Reduce(function(...) rbind(...), weights_list)
#all_dataframe<-rbind(weights_list)
write.table(weight_data, file.path(outdir, "weights.tsv"), quote = F, row.names = T, col.names = T, sep="\t")
dev.off()
	
