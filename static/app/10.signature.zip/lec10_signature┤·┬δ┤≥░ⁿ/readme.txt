Purpose:Signature analysis

Tools:R packages deconstructSigs，BSgenome.Hsapiens.UCSC.hg19 and BSgenome.Hsapiens.UCSC.hg38.

##eg：Rscript deconstructSig_new.R sig_test.tsv PGM25,PGM45,PGM53,PGM65,PGM7 /data/zss/Rscript-zss/app/signature/result BSgenome.Hsapiens.UCSC.hg19
#sig_test:input file
#PGM25,PGM45,PGM53,PGM65,PGM7:sample_ids
#/data/zss/Rscript-zss/app/signature/result:outdir
#BSgenome.Hsapiens.UCSC.hg19:referrence genome(BSgenome.Hsapiens.UCSC.hg19  or  BSgenome.Hsapiens.UCSC.hg38)


# This part could run using external parameters 
#args <- commandArgs(TRUE)
#sample_mut_path=args[1]
#sample_ids=args[2]
#outdir=args[3]
#BSg_type=args[4]