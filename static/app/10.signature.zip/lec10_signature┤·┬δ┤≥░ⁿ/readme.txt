Purpose:Signature and frequency analysis

Tools:R packages deconstructSigs，BSgenome.Hsapiens.UCSC.hg19 and BSgenome.Hsapiens.UCSC.hg38.

##eg：sh run_signature96_auto.sh sig_test.tsv freq96.tsv BSgenome.Hsapiens.UCSC.hg19 /data/zss/Rscript-zss/app/signature/new/result
#$1=sig.input,
$2=out.freq,
$3=BSgenome.Hsapiens.UCSC.hg19 or BSgenome.Hsapiens.UCSC.hg38,
$4=out_dir---eg:/data/zss/Rscript-zss/app/signature/new/result


