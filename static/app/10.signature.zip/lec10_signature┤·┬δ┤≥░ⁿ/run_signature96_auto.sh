#docker run -it -v /public/jingdu:/data -v  /public/jingdu/budechao/scripts:/program bc_deconstructsigs /bin/bash
#$1=sig.input,$2=out.freq,$3=BSgenome.Hsapiens.UCSC.hg19 or BSgenome.Hsapiens.UCSC.hg38,$4=out_dir---eg:/data/zss/Rscript-zss/app/signature/new/result
#eg:sh run_signature96_auto.sh sig_test.tsv freq96.tsv BSgenome.Hsapiens.UCSC.hg19 /data/zss/Rscript-zss/app/signature/new/result
if [ ! -d $4 ];then mkdir $4;fi
Rscript /data/zss/Rscript-zss/app/signature/new/get_freq_trinucleotide.R $1 $4/$2 $3
Rscript /data/zss/Rscript-zss/app/signature/new/deconstructSig_new.R $1  $4 $3
sed -i '1s/^.*/sample\t&/' $4/$2
sed -i '1s/^.*/sample\t&/' $4/weights.tsv
